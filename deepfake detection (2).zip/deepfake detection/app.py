"""
app.py — Cinematic DeepFake Forensics Dashboard UI.
Strict 45-second cinematic scan using native Streamlit primitives to ensure stability.
"""

import time
import datetime
import numpy as np
import pandas as pd
import streamlit as st
from PIL import Image

import utils
import detector
import forensics
import visualizer
import scorer

# ── Page Config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Forensics Terminal",
    page_icon="👁️‍🗨️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Session State Init ────────────────────────────────────────────────────────
if "scan_history" not in st.session_state:
    st.session_state.scan_history = []
if "show_technical" not in st.session_state:
    st.session_state.show_technical = False
if "scan_active" not in st.session_state:
    st.session_state.scan_active = False
if "scan_done" not in st.session_state:
    st.session_state.scan_done = False
if "results" not in st.session_state:
    st.session_state.results = None
if "ref_img_bytes" not in st.session_state:
    st.session_state.ref_img_bytes = None
if "ref_img_name" not in st.session_state:
    st.session_state.ref_img_name = None

# ── Custom CSS (High-End Cyberpunk / Forensics) ──────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Courier+Prime:wght@400;700&family=Orbitron:wght@500;700&display=swap');

/* Global Styles */
html, body, .stApp {
    background: radial-gradient(circle at 50% 0%, #061122 0%, #010409 100%) !important;
    color: #e0e6ed !important;
    font-family: 'Courier Prime', 'Courier New', monospace !important;
}

/* Hide default Streamlit elements */
#MainMenu {visibility: hidden;}
footer {visibility: hidden;}
header {background: transparent !important;}

/* Glassmorphism Base Card */
.glass-card {
    background: rgba(13, 22, 38, 0.5);
    backdrop-filter: blur(16px);
    -webkit-backdrop-filter: blur(16px);
    border: 1px solid rgba(0, 255, 136, 0.2);
    border-radius: 16px;
    padding: 24px;
    box-shadow: 0 10px 40px 0 rgba(0, 0, 0, 0.8), inset 0 0 20px rgba(0, 255, 136, 0.05);
    margin-bottom: 24px;
}

/* Engine Cards */
.engine-card-container {
    background: rgba(10, 16, 28, 0.7);
    backdrop-filter: blur(12px);
    border: 1px solid rgba(0, 170, 255, 0.25);
    border-radius: 14px;
    padding: 20px;
    margin-bottom: 16px;
    height: 100%;
    position: relative;
    overflow: hidden;
}
.engine-card-container::before {
    content: ''; position: absolute; top: 0; left: 0; width: 4px; height: 100%;
    background: #00aaff; box-shadow: 0 0 10px #00aaff;
}
.engine-title {
    color: #00aaff; font-family: 'Orbitron', sans-serif; font-size: 1.1rem; font-weight: 700;
    margin-bottom: 8px; border-bottom: 1px solid rgba(0, 170, 255, 0.2); padding-bottom: 4px;
    letter-spacing: 1px;
}
.engine-status { color: #a0aec0; font-size: 0.85rem; margin-top: 8px; margin-bottom: 4px; font-weight:bold; }
.engine-desc { color: #718096; font-size: 0.75rem; font-style: italic; }

/* Verdict Panels */
.verdict-panel {
    border-radius: 16px; padding: 40px; text-align: center; position: relative; overflow: hidden;
    background: rgba(5, 8, 15, 0.9); backdrop-filter: blur(20px);
}
.verdict-fake {
    border: 2px solid #ff3333;
    box-shadow: 0 0 50px rgba(255, 51, 51, 0.4), inset 0 0 30px rgba(255, 51, 51, 0.15);
}
.verdict-real {
    border: 2px solid #00ff88;
    box-shadow: 0 0 50px rgba(0, 255, 136, 0.3), inset 0 0 30px rgba(0, 255, 136, 0.15);
}

.verdict-title {
    font-family: 'Orbitron', sans-serif; font-size: 3.5rem; font-weight: 700; letter-spacing: 6px;
    margin-bottom: 15px; text-shadow: 0 0 20px currentColor; text-transform: uppercase;
}
.verdict-fake .verdict-title { color: #ff3333; animation: glitch 2s infinite; }
.verdict-real .verdict-title { color: #00ff88; }

.scan-meta { font-size: 0.9rem; color: #8bb4e7; margin-bottom: 20px; letter-spacing: 2px; }
.stat-row { display: flex; justify-content: center; gap: 50px; margin-top: 30px; }
.stat-box {
    background: rgba(0,0,0,0.6); padding: 15px 25px; border-radius: 10px;
    border: 1px solid rgba(255,255,255,0.1); box-shadow: inset 0 0 10px rgba(255,255,255,0.05);
}
.stat-label { font-size: 0.8rem; color: #a0aec0; display: block; margin-bottom: 6px; text-transform: uppercase; letter-spacing: 1px; }

/* Image Labels */
.image-label {
    text-align: center; font-size: 0.8rem; color: #00aaff; margin-top: 10px; letter-spacing: 2px;
    text-transform: uppercase; font-weight: 700; background: rgba(0, 170, 255, 0.1);
    padding: 6px; border-radius: 6px; border: 1px solid rgba(0, 170, 255, 0.3); box-shadow: 0 0 10px rgba(0,170,255,0.1);
}

/* Sidebar */
section[data-testid="stSidebar"] {
    background-color: rgba(3, 5, 10, 0.98) !important;
    border-right: 1px solid rgba(0, 255, 136, 0.3);
}
.sidebar-header {
    font-family: 'Orbitron', sans-serif; color: #00ff88; font-size: 1.3rem; font-weight: 700;
    text-align: center; letter-spacing: 4px; text-shadow: 0 0 10px rgba(0, 255, 136, 0.6);
    margin-bottom: 25px; padding-bottom: 15px; border-bottom: 1px solid rgba(0, 255, 136, 0.3);
}

/* Typography */
h1, h2, h3 { color: #ffffff !important; font-family: 'Orbitron', sans-serif !important; letter-spacing: 2px; }
.section-title {
    font-family: 'Orbitron', sans-serif; font-size: 1.5rem; color: #e2e8f0;
    border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 10px; margin-bottom: 25px;
    text-transform: uppercase; letter-spacing: 3px; text-shadow: 0 0 10px rgba(255,255,255,0.2);
}

/* Buttons */
.stButton > button {
    background: rgba(0, 255, 136, 0.15) !important; border: 1px solid #00ff88 !important;
    color: #00ff88 !important; font-family: 'Orbitron', sans-serif !important; letter-spacing: 3px !important;
    padding: 16px 32px !important; border-radius: 8px !important; text-transform: uppercase;
    font-weight: bold; width: 100%; box-shadow: 0 0 15px rgba(0,255,136,0.2) !important;
    transition: all 0.2s ease-in-out !important;
}
.stButton > button:hover {
    background: rgba(0, 255, 136, 0.3) !important; box-shadow: 0 0 30px rgba(0, 255, 136, 0.6) !important;
    transform: scale(1.02);
}

/* File Uploader styling */
[data-testid="stFileUploadDropzone"] {
    background: rgba(10, 16, 28, 0.6) !important; border: 2px dashed rgba(0, 170, 255, 0.6) !important;
    border-radius: 12px !important; padding: 40px !important;
}

/* Progress Bars custom */
.stProgress > div > div > div {
    background: linear-gradient(90deg, #00ff88, #00aaff) !important;
    box-shadow: 0 0 10px #00ff88;
    transition: width 0.1s linear !important;
}
</style>
""", unsafe_allow_html=True)

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown('<div class="sidebar-header">SYS.CORE // FORENSICS</div>', unsafe_allow_html=True)
    
    st.markdown("""
    <div style='color:#8bb4e7; font-size:0.85rem; margin-bottom:25px; text-align:justify; line-height:1.6;'>
    Advanced DeepFake Forensics Terminal. Utilizing 5 independent heuristic engines to detect synthetic facial manipulation via structural and spectral anomalies.
    </div>
    """, unsafe_allow_html=True)

    st.markdown("<div style='color:#e2e8f0; font-family:Orbitron, sans-serif; font-size:0.9rem; letter-spacing:2px; margin-bottom:15px;'>ACTIVE ENGINES</div>", unsafe_allow_html=True)
    engines_info = [
        ("🔴", "ELA Analysis", "JPEG artifact detection"),
        ("🌊", "FFT Spectrum", "GAN frequency fingerprint"),
        ("📐", "Geometry", "468-pt facial ratios"),
        ("🧬", "Texture Entropy", "Skin micro-texture"),
        ("🟣", "Color Boundary", "Blend boundary delta"),
        ("🆔", "Face ID Compare", "Reference identity match"),
    ]
    for icon, name, desc in engines_info:
        st.markdown(
            f"""
            <div style="background:rgba(0,0,0,0.4); border:1px solid rgba(255,255,255,0.05); padding:10px; border-radius:8px; margin-bottom:10px; display:flex; align-items:center; gap:12px;">
                <div style="font-size:1.3rem; filter:drop-shadow(0 0 5px currentColor);">{icon}</div>
                <div>
                    <div style="color:#00aaff; font-weight:bold; font-size:0.85rem; letter-spacing:1px;">{name}</div>
                    <div style="color:#718096; font-size:0.7rem;">{desc}</div>
                </div>
            </div>
            """, unsafe_allow_html=True
        )

# ── Cinematic Scan Sequence ──────────────────────────────────────────────
if st.session_state.scan_active and not st.session_state.scan_done:
    # 1) Global CSS to hide sidebar and header, forcing full screen look
    st.markdown("""
    <style>
    [data-testid="stSidebar"] { display: none !important; }
    header { display: none !important; }
    .block-container { padding-top: 2rem !important; max-width: 1000px !important; }
    .stApp { background: radial-gradient(circle at center, #020b14 0%, #000000 100%) !important; }
    
    .face-box {
        position: relative; width: 350px; height: 400px;
        background: rgba(0, 20, 40, 0.3); border: 1px solid rgba(0,255,136,0.4);
        box-shadow: inset 0 0 60px rgba(0,170,255,0.3), 0 0 40px rgba(0,255,136,0.1);
        border-radius: 20px; overflow: hidden; margin: 0 auto 30px auto; z-index: 2;
    }
    .laser {
        position: absolute; width: 100%; height: 3px; background: #00ff88;
        box-shadow: 0 0 20px #00ff88, 0 0 40px #00ff88;
        animation: laser-scan 3.5s ease-in-out infinite; z-index: 10;
    }
    .grid {
        position: absolute; width: 100%; height: 100%;
        background-image: 
            linear-gradient(rgba(0, 170, 255, 0.3) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0, 170, 255, 0.3) 1px, transparent 1px);
        background-size: 25px 25px; opacity: 0.6;
    }
    .svg-face {
        position: absolute; top: 10%; left: 10%; width: 80%; height: 80%;
        fill: none; stroke: rgba(0,170,255,0.8); stroke-width: 1.5;
        stroke-dasharray: 400; stroke-dashoffset: 400;
        animation: draw-face 4s forwards, pulse-glow 3s infinite 4s;
    }
    
    .scan-text-main {
        color: #00ff88; font-family: 'Orbitron', sans-serif; font-size: 2.2rem;
        letter-spacing: 5px; margin-bottom: 10px; text-shadow: 0 0 15px #00ff88; text-align: center;
    }
    .scan-text-sub {
        color: #00aaff; font-family: 'Courier Prime', monospace; font-size: 1.2rem;
        letter-spacing: 2px; margin-bottom: 30px; opacity: 0.8; text-align: center;
    }
    
    .log-box {
        background: linear-gradient(90deg, rgba(0,170,255,0.05) 0%, transparent 100%);
        border-left: 3px solid #00aaff; padding: 20px; height: 200px;
        display: flex; flex-direction: column; justify-content: flex-end; overflow: hidden;
        border-radius: 0 10px 10px 0; margin-top: 20px;
    }
    .log-line { color: #8bb4e7; font-family: 'Courier Prime', monospace; font-size: 1.1rem; margin-bottom: 8px; opacity: 0.9; text-shadow: 0 0 5px rgba(139,180,231,0.5);}
    
    @keyframes laser-scan { 0% { top: -10px; } 50% { top: 100%; } 100% { top: -10px; } }
    @keyframes draw-face { to { stroke-dashoffset: 0; } }
    @keyframes pulse-glow { 0%, 100% { filter: drop-shadow(0 0 5px #00aaff); } 50% { filter: drop-shadow(0 0 25px #00aaff); } }
    @keyframes blink { 0%, 100% { opacity: 1; } 50% { opacity: 0; } }
    </style>
    """, unsafe_allow_html=True)
    
    st.markdown('<div class="scan-text-main">FORENSIC SCAN ACTIVE</div>', unsafe_allow_html=True)
    sub_title_ph = st.empty()
    
    # Render complex SVG animation exactly ONCE to prevent Streamlit rendering crashes
    st.markdown("""
    <div class="face-box">
        <div class="grid"></div>
        <svg class="svg-face" viewBox="0 0 100 100">
            <path d="M50 5 C25 5 15 25 15 50 C15 75 35 95 50 98 C65 95 85 75 85 50 C85 25 75 5 50 5 Z" />
            <path d="M30 45 Q35 40 40 45" />
            <path d="M70 45 Q65 40 60 45" />
            <line x1="35" y1="75" x2="65" y2="75" />
            <circle cx="35" cy="48" r="3" fill="#00ff88" />
            <circle cx="65" cy="48" r="3" fill="#00ff88" />
            <path d="M50 50 L50 65" stroke="#00aaff" stroke-width="2"/>
            <circle cx="50" cy="50" r="1.5" fill="#00aaff" />
        </svg>
        <div class="laser"></div>
    </div>
    """, unsafe_allow_html=True)
    
    # Native progress bar
    prog_bar = st.progress(0)
    
    # Logs placeholder
    logs_ph = st.empty()
    log_lines = []
    
    def run_stage(start_pct, end_pct, duration, msg, sub):
        sub_title_ph.markdown(f'<div class="scan-text-sub">[{sub}]</div>', unsafe_allow_html=True)
        log_lines.append(msg)
        if len(log_lines) > 6:
            log_lines.pop(0)
            
        logs_html = "".join([f'<div class="log-line">> {l}</div>' for l in log_lines])
        logs_ph.markdown(f"""
        <div class="log-box">
            {logs_html}
            <div class="log-line" style="color:#00ff88; font-weight:bold; font-size:1.2rem;">> <span style="animation:blink 1s infinite">█</span></div>
        </div>
        """, unsafe_allow_html=True)
        
        steps = int(duration * 5) # 5 updates per second
        if steps <= 0: return
        sleep_time = duration / steps
        for i in range(steps):
            pct = start_pct + (end_pct - start_pct) * (i / steps)
            prog_bar.progress(int(pct))
            time.sleep(sleep_time)

    # EXACT 45-SECOND TIMED EXECUTION
    run_stage(0, 10, 4.0, "[✔] Initializing forensic engine...", "INITIALIZING CORE")
    run_stage(10, 22, 5.0, "[✔] Loading facial structure model...", "DETECTING FACIAL BOUNDARIES")
    run_stage(22, 36, 6.0, "[✔] Running compression artifact analysis...", "ERROR LEVEL ANALYSIS (ELA)")
    run_stage(36, 50, 6.0, "[✔] Performing frequency decomposition...", "FFT SPECTRUM GENERATION")
    run_stage(50, 63, 5.0, "[✔] Validating geometric consistency...", "MAPPING 468-PT LANDMARKS")
    run_stage(63, 74, 4.0, "[✔] Computing texture entropy...", "LOCAL BINARY PATTERN (LBP)")
    run_stage(74, 83, 4.0, "[✔] Analyzing color boundary transitions...", "COLOR DELTA EXTRACTION")
    run_stage(83, 95, 7.0, "[✔] Comparing facial identity with reference image...", "REFERENCE FACE COMPARISON")
    run_stage(95, 100, 4.0, "[✔] Compiling forensic report...", "AGGREGATING CONFIDENCE METRICS")

    sub_title_ph.markdown('<div class="scan-text-sub">[PREPARING RESULTS]</div>', unsafe_allow_html=True)
    prog_bar.progress(100)
    time.sleep(1)
    
    # Transition
    st.session_state.scan_done = True
    st.session_state.scan_active = False
    
    # Flash bang
    st.markdown("""
    <style>
    .flash { position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: #ffffff; z-index: 9999999; animation: fadeout 1.2s forwards; }
    @keyframes fadeout { 0% { opacity: 1; } 100% { opacity: 0; display:none; } }
    </style>
    <div class="flash"></div>
    """, unsafe_allow_html=True)
    time.sleep(0.5)
    st.rerun()

# ── Main Dashboard (Only shown when not scanning) ─────────────────────────────
if not st.session_state.scan_active:
    st.markdown("""
    <div style="text-align:center; margin-bottom: 50px;">
        <h1 style="color:#00ff88; font-size: 3rem; text-shadow:0 0 30px rgba(0,255,136,0.5); margin-bottom:10px;">DEEPFAKE FORENSICS LAB</h1>
        <div style="color:#00aaff; font-family:'Courier Prime', monospace; font-size:1rem; letter-spacing:4px; opacity: 0.8;">[ ADVANCED CYBERSECURITY ANALYSIS TOOL ]</div>
    </div>
    """, unsafe_allow_html=True)

    if not st.session_state.scan_done:
        st.markdown("""
        <div class="glass-card" style="padding:28px 32px 20px;">
            <div class="section-title" style="margin-bottom:18px;">00 // EVIDENCE INGESTION</div>
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:24px;">
        """, unsafe_allow_html=True)

        col_ref, col_test = st.columns(2)

        with col_ref:
            st.markdown("""
            <div style="color:#00ff88; font-family:'Orbitron',sans-serif; font-size:0.9rem;
                        letter-spacing:2px; margin-bottom:10px;">
            👤 REFERENCE IMAGE &nbsp;<span style="color:#4a5568; font-size:0.75rem;">[ Your Real Photo ]</span>
            </div>""", unsafe_allow_html=True)
            ref_upload = st.file_uploader(
                "Upload Your Real Image",
                type=["jpg", "jpeg", "png"],
                key="ref_uploader",
                label_visibility="collapsed",
            )

        with col_test:
            st.markdown("""
            <div style="color:#00aaff; font-family:'Orbitron',sans-serif; font-size:0.9rem;
                        letter-spacing:2px; margin-bottom:10px;">
            🔍 TEST IMAGE &nbsp;<span style="color:#4a5568; font-size:0.75rem;">[ Image to Analyze ]</span>
            </div>""", unsafe_allow_html=True)
            test_upload = st.file_uploader(
                "Upload Image to Analyze",
                type=["jpg", "jpeg", "png"],
                key="test_uploader",
                label_visibility="collapsed",
            )

        st.markdown("</div></div>", unsafe_allow_html=True)

        # ── Validation ────────────────────────────────────────────────────────
        if ref_upload is None and test_upload is None:
            st.markdown("""
            <div class="glass-card" style="text-align:center; padding:60px;">
                <div style="font-size:3.5rem; margin-bottom:16px; opacity:0.6;">&#x1F4E5;</div>
                <div style="color:#8bb4e7; font-family:'Orbitron',sans-serif; font-size:1.3rem;
                            letter-spacing:3px;">AWAITING DUAL EVIDENCE INGESTION</div>
                <div style="color:#4a5568; font-size:0.85rem; margin-top:12px;">
                    Upload BOTH a reference image and the image to analyze.
                </div>
            </div>""", unsafe_allow_html=True)
            st.stop()

        if ref_upload is None or test_upload is None:
            st.error("[ INPUT REQUIRED ] — Please upload both reference and test image")
            st.stop()

        # ── Load & validate both images ───────────────────────────────────────
        ref_bytes = ref_upload.getvalue()
        test_bytes = test_upload.getvalue()

        ref_val = utils.validate_upload(ref_bytes, ref_upload.name)
        test_val = utils.validate_upload(test_bytes, test_upload.name)

        if not ref_val["valid"]:
            st.error(f"REFERENCE IMAGE ERROR: {ref_val['error']}")
            st.stop()
        if not test_val["valid"]:
            st.error(f"TEST IMAGE ERROR: {test_val['error']}")
            st.stop()

        ref_pil  = utils.resize_image(utils.load_image(ref_bytes))
        img_pil  = utils.resize_image(utils.load_image(test_bytes))
        ref_arr  = utils.pil_to_numpy(ref_pil)
        img_arr  = utils.pil_to_numpy(img_pil)
        meta     = utils.get_image_metadata(test_bytes, test_upload.name)

        # Previews side by side
        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        st.markdown('<div class="section-title">01 // Evidence Metadata</div>', unsafe_allow_html=True)

        m1, m2, m3, m4, m5 = st.columns(5)
        for col, label, val in zip(
            [m1, m2, m3, m4, m5],
            ["FILE_ID", "RESOLUTION", "SIZE", "CHANNELS", "CODEC"],
            [meta["filename"][:15]+"..." if len(meta["filename"])>15 else meta["filename"],
             meta["resolution"], meta["file_size"], meta["color_mode"], meta["format"]],
        ):
            col.markdown(f"""
                <div style="background:rgba(0,0,0,0.5); border:1px solid rgba(0,170,255,0.2);
                            border-radius:10px; padding:15px; text-align:center;">
                    <div style="color:#718096; font-size:0.75rem; letter-spacing:2px;
                                margin-bottom:8px;">{label}</div>
                    <div style="color:#e2e8f0; font-weight:bold; font-size:1rem;
                                font-family:'Courier Prime',monospace;">{val}</div>
                </div>
            """, unsafe_allow_html=True)

        st.markdown('<br>', unsafe_allow_html=True)
        pc1, pc2 = st.columns(2)
        with pc1:
            st.image(ref_pil, caption="REFERENCE IMAGE", use_container_width=False, width=280)
        with pc2:
            st.image(img_pil, caption="TEST IMAGE", use_container_width=False, width=280)
        st.markdown('</div>', unsafe_allow_html=True)

        col1, col2, col3 = st.columns([1,2,1])
        with col2:
            if st.button("▶ START FORENSIC ANALYSIS"):
                # ── Backend computation ───────────────────────────────────────
                bbox = detector.detect_face(img_arr)
                if bbox is None:
                    st.error("CRITICAL FAILURE: No human face detected in test image.")
                    st.stop()

                ref_bbox = detector.detect_face(ref_arr)
                if ref_bbox is None:
                    st.error("CRITICAL FAILURE: No human face detected in reference image.")
                    st.stop()

                landmarks      = detector.extract_landmarks(img_arr)
                ref_landmarks  = detector.extract_landmarks(ref_arr)
                face_roi       = detector.get_face_roi(img_arr, bbox)

                ela_result  = forensics.run_ela(img_pil, face_roi)
                fft_result  = forensics.run_fft(face_roi)
                geo_result  = forensics.run_geometry(landmarks, img_arr.shape)
                tex_result  = forensics.run_texture(face_roi)
                col_result  = forensics.run_color(img_arr, bbox)
                face_cmp    = forensics.run_face_comparison(
                    ref_landmarks, ref_arr.shape,
                    landmarks,     img_arr.shape,
                )

                engine_scores = {
                    "ela": ela_result["score"], "fft": fft_result["score"],
                    "geometry": geo_result["score"], "texture": tex_result["score"],
                    "color": col_result["score"],
                }
                verdict = scorer.compute_verdict(engine_scores)

                # Integrate face comparison into final verdict
                verdict = scorer.integrate_face_comparison(verdict, face_cmp)

                st.session_state.results = {
                    "bbox": bbox, "landmarks": landmarks, "ela": ela_result,
                    "fft": fft_result, "geo": geo_result, "tex": tex_result,
                    "col": col_result, "face_cmp": face_cmp, "verdict": verdict,
                    "img_arr": img_arr, "img_pil": img_pil,
                    "ref_pil": ref_pil,
                    "scan_id": utils.generate_scan_id(),
                    "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }

                st.session_state.scan_active = True
                st.session_state.scan_done   = False
                st.rerun()

    # Dashboard Rendering (Post-Scan)
    if st.session_state.scan_done and st.session_state.results:
        res = st.session_state.results
        
        # Guard against old session state cache
        if "img_arr" not in res:
            for key in ["scan_active", "scan_done", "results"]:
                st.session_state.pop(key, None)
            st.rerun()

        bbox = res["bbox"]
        landmarks = res["landmarks"]
        ela_result = res["ela"]
        fft_result = res["fft"]
        geo_result = res["geo"]
        tex_result = res["tex"]
        col_result = res["col"]
        face_cmp   = res.get("face_cmp", {"similarity_score": 0, "status": "N/A", "match": False})
        verdict    = res["verdict"]
        scan_id    = res["scan_id"]
        timestamp  = res["timestamp"]
        img_arr    = res["img_arr"]
        img_pil    = res["img_pil"]
        ref_pil    = res.get("ref_pil", None)

        is_fake = verdict["is_fake"]
        panel_class = "verdict-fake" if is_fake else "verdict-real"
        v_title = "DEEPFAKE DETECTED" if is_fake else "AUTHENTIC"
        
        risk_colors = {"LOW RISK": "#00ff88", "MODERATE RISK": "#ffcc00", "HIGH RISK": "#ff8800", "CRITICAL": "#ff3333"}
        risk_color = risk_colors.get(verdict["risk_level"], "#aaa")

        st.markdown(f"""
        <div class="glass-card {panel_class}">
            <div class="scan-meta">SCAN_ID: {scan_id} &nbsp;|&nbsp; TIMESTAMP: {timestamp}</div>
            <div class="verdict-title">[{v_title}]</div>
            <div class="stat-row">
                <div class="stat-box">
                    <span class="stat-label">Confidence</span>
                    <span style="color:white; font-family:'Orbitron', sans-serif; font-size:1.5rem;">{verdict["confidence"]}%</span>
                </div>
                <div class="stat-box">
                    <span class="stat-label">Risk Level</span>
                    <span style="color:{risk_color}; font-family:'Orbitron', sans-serif; font-size:1.5rem;">{verdict["risk_level"]}</span>
                </div>
                <div class="stat-box">
                    <span class="stat-label">System Score</span>
                    <span style="color:white; font-family:'Orbitron', sans-serif; font-size:1.5rem;">{verdict["fake_score"]}/100</span>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)

        # ── REFERENCE COMPARISON RESULT ─────────────────────────────────
        sim_score = face_cmp.get("similarity_score", 0)
        cmp_match = face_cmp.get("match", False)
        cmp_status = face_cmp.get("status", "N/A")
        match_color = "#00ff88" if cmp_match else "#ff3333"
        match_icon  = "✅" if cmp_match else "❌"

        # Integrated conclusion label
        if not is_fake and cmp_match:
            conclusion = "🟢 AUTHENTIC — Image appears real and identity matches reference."
        elif is_fake and not cmp_match:
            conclusion = "🔴 STRONG FAKE — Image shows deepfake signals AND face mismatch detected."
        elif not is_fake and not cmp_match:
            conclusion = "🟡 POSSIBLE FACE SWAP — Image looks real but identity does not match reference."
        else:
            conclusion = "🟠 SUSPICIOUS — Deepfake indicators present despite facial similarity."

        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        st.markdown('<div class="section-title">\U0001f194 REFERENCE COMPARISON RESULT</div>', unsafe_allow_html=True)

        rc1, rc2, rc3 = st.columns([1, 1, 1])
        with rc1:
            if ref_pil is not None:
                st.image(ref_pil, caption="REFERENCE IMAGE", use_container_width=True)
        with rc2:
            st.image(img_pil, caption="TEST IMAGE", use_container_width=True)
        with rc3:
            bar_width = int(sim_score)
            st.markdown(f"""
            <div style="padding:20px; background:rgba(0,0,0,0.5); border-radius:12px;
                        border:1px solid {match_color}; box-shadow:0 0 20px {match_color}40;">
                <div style="color:#a0aec0; font-size:0.75rem; letter-spacing:2px;
                            margin-bottom:8px;">IDENTITY SIMILARITY</div>
                <div style="color:{match_color}; font-family:'Orbitron',sans-serif;
                            font-size:2.8rem; font-weight:700; margin-bottom:6px;">
                    {sim_score}%
                </div>
                <div style="background:rgba(255,255,255,0.1); border-radius:6px;
                            height:10px; margin-bottom:16px;">
                    <div style="background:{match_color}; width:{bar_width}%;
                                height:10px; border-radius:6px;
                                box-shadow:0 0 8px {match_color};"></div>
                </div>
                <div style="color:{match_color}; font-family:'Orbitron',sans-serif;
                            font-size:1rem; font-weight:700; letter-spacing:2px;
                            margin-bottom:10px;">{match_icon} {cmp_status}</div>
                <div style="color:#718096; font-size:0.75rem; font-style:italic;
                            line-height:1.5;">{conclusion}</div>
            </div>
            """, unsafe_allow_html=True)

        st.markdown('</div>', unsafe_allow_html=True)

        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        st.markdown('<div class="section-title">02 // Spatial Analysis</div>', unsafe_allow_html=True)

        i1, i2, i3 = st.columns(3)
        bbox_img = detector.draw_face_bbox(img_arr, bbox, is_fake)
        mesh_overlay_arr = detector.draw_landmark_mesh(img_arr, landmarks) if landmarks else None
        ela_viz = visualizer.render_ela_heatmap(ela_result["ela_image"], ela_result["mean_ela"]) if ela_result["ela_image"] else None

        with i1:
            st.image(bbox_img, use_container_width=True)
            st.markdown('<div class="image-label">SOURCE + ROI BBOX</div>', unsafe_allow_html=True)
        with i2:
            st.image(mesh_overlay_arr if mesh_overlay_arr is not None else img_arr, use_container_width=True)
            st.markdown('<div class="image-label">GEOMETRIC MESH (468 PT)</div>', unsafe_allow_html=True)
        with i3:
            if ela_viz:
                st.image(ela_viz, use_container_width=True)
            st.markdown('<div class="image-label">ERROR LEVEL HEATMAP</div>', unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)

        st.markdown('<div class="section-title">03 // Heuristic Engines</div>', unsafe_allow_html=True)
        fft_viz = visualizer.render_fft_spectrum(fft_result.get("log_magnitude"), fft_result["periodicity_score"])
        lbp_viz = visualizer.render_lbp_visual(tex_result.get("lbp_image"), tex_result["entropy"])
        color_viz = visualizer.render_color_chart(col_result["face_stats"], col_result["border_stats"], col_result["delta_score"])

        engines_data = [
            ("ELA_COMPRESSION", ela_result, "JPEG artifacts hotspot detection.", ela_viz),
            ("FFT_SPECTRUM", fft_result, "GAN frequency periodicity mapping.", fft_viz),
            ("GEO_LANDMARK", geo_result, "Facial ratio biological constraint check.", None),
            ("LBP_ENTROPY", tex_result, "Micro-texture synthetic smoothing check.", lbp_viz),
            ("COLOR_DELTA", col_result, "Face-to-background blend boundary check.", color_viz),
        ]

        c1, c2 = st.columns(2)
        for idx, (title, result, desc, viz) in enumerate(engines_data):
            col = c1 if idx % 2 == 0 else c2
            score = result["score"]
            status = result["status"]
            score_color = "#ff3333" if score > 65 else "#ffcc00" if score > 40 else "#00ff88"
            with col:
                st.markdown(f"""
                <div class="engine-card-container">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <div class="engine-title">{title}</div>
                        <div style="color:{score_color}; font-weight:bold; font-size:1.3rem; font-family:'Orbitron', sans-serif;">{score}/100</div>
                    </div>
                    <div class="engine-status">> {status}</div>
                    <div class="engine-desc">{desc}</div>
                </div>
                """, unsafe_allow_html=True)
                if viz is not None:
                    st.image(viz, use_container_width=True)
                    st.markdown("<br>", unsafe_allow_html=True)
        st.markdown('<br>', unsafe_allow_html=True)

        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        st.markdown('<div class="section-title">04 // Geometry Output</div>', unsafe_allow_html=True)
        if geo_result.get("table"):
            df = pd.DataFrame(geo_result["table"])
            def style_dataframe(row):
                is_fail = "FAIL" in str(row["Status"])
                color = 'color: #ff3333; background-color: rgba(255, 51, 51, 0.1); font-weight: bold;' if is_fail else 'color: #00ff88;'
                return [color] * len(row)
            styled = df.style.apply(style_dataframe, axis=1).set_properties(**{
                'background-color': 'rgba(10, 16, 28, 0.6)', 'border-color': 'rgba(0,170,255,0.2)', 'font-family': 'Courier Prime, monospace'
            })
            st.dataframe(styled, use_container_width=True, hide_index=True)
        st.markdown('</div>', unsafe_allow_html=True)

        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        st.markdown('<div class="section-title">FREQUENCY DOMAIN ANALYSIS — GAN SIGNATURE DETECTION</div>', unsafe_allow_html=True)
        st.image(fft_viz, use_container_width=True)
        st.markdown('<div style="text-align:center; color:#8bb4e7; font-size:0.9rem; margin-top:10px;"><i>ANNOTATION: High-variance concentric grid patterns indicate upsampling artifacts inherent in Generative Adversarial Networks.</i></div>', unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)

        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        st.markdown('<div class="section-title">05 // Export Protocol</div>', unsafe_allow_html=True)

        def to_b64(img_obj):
            if img_obj is None: return ""
            if isinstance(img_obj, np.ndarray):
                from PIL import Image
                img_obj = Image.fromarray(img_obj)
            import base64
            from io import BytesIO
            buf = BytesIO()
            img_obj.save(buf, format="PNG")
            return base64.b64encode(buf.getvalue()).decode("utf-8")

        def generate_rich_html_report(scan_id, timestamp, engines, verdict, images, geo_table, face_cmp=None):
            risk_colors = {"LOW RISK": "#00ff88", "MODERATE RISK": "#ffcc00", "HIGH RISK": "#ff8800", "CRITICAL": "#ff3333"}
            r_color = risk_colors.get(verdict["risk_level"], "#aaa")
            v_title = "DEEPFAKE DETECTED" if verdict["is_fake"] else "AUTHENTIC"

            fc = face_cmp or {}
            sim = fc.get("similarity_score", "N/A")
            cmp_lbl = fc.get("status", "N/A")
            match_str = "MATCH" if fc.get("match", False) else "MISMATCH"

            if verdict["is_fake"]:
                summary = ("Analysis indicates statistically significant anomalies in frequency distribution, "
                           "texture entropy, and error level patterns consistent with synthetic image generation. "
                           f"Additionally, reference identity comparison result: {match_str} (Similarity: {sim}%). "
                           "Analysis indicates whether the subject in the test image matches the provided reference image.")
            else:
                summary = ("Analysis indicates spatial, spectral, and geometric heuristics fall within natural "
                           "biological and optical tolerances. No definitive evidence of synthetic manipulation found. "
                           f"Reference identity comparison result: {match_str} (Similarity: {sim}%). "
                           "Analysis indicates whether the subject in the test image matches the provided reference image.")

            table_rows = ""
            if geo_table:
                for row in geo_table:
                    status_cls = "fail" if "FAIL" in str(row['Status']) else "pass"
                    table_rows += f"<tr><td>{row['Metric']}</td><td>{row['Measured']}</td><td>{row['Normal Range']}</td><td>{row['Deviation']}</td><td class='{status_cls}'>{row['Status']}</td></tr>"

            html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>DeepFake Forensic Report - {scan_id}</title>
    <style>
        body {{ font-family: 'Courier New', Courier, monospace; background-color: #060b14; color: #c9d1d9; padding: 40px; margin: 0; }}
        .header {{ text-align: center; border-bottom: 2px solid #00ff88; padding-bottom: 20px; margin-bottom: 30px; }}
        .header h1 {{ color: #00ff88; margin: 0; font-size: 28px; letter-spacing: 2px; font-weight: bold; }}
        .meta {{ text-align: center; color: #58a6ff; font-size: 14px; margin-bottom: 40px; letter-spacing: 1px; }}
        .verdict-box {{ background: rgba(0, 255, 136, 0.05); border: 1px solid {r_color}; border-left: 8px solid {r_color}; padding: 25px; border-radius: 8px; margin-bottom: 40px; }}
        .verdict-box h2 {{ margin-top: 0; color: {r_color}; font-size: 24px; letter-spacing: 2px; }}
        .section-title {{ color: #00aaff; font-size: 20px; border-bottom: 1px solid rgba(0, 170, 255, 0.3); padding-bottom: 8px; margin-top: 50px; margin-bottom: 25px; text-transform: uppercase; font-weight: bold; letter-spacing: 1px; }}
        .grid {{ display: flex; flex-wrap: wrap; gap: 20px; }}
        .card {{ background: rgba(10, 16, 28, 0.8); border: 1px solid rgba(0, 170, 255, 0.2); border-radius: 8px; padding: 20px; flex: 1 1 calc(33.333% - 20px); box-sizing: border-box; text-align: center; }}
        .card-wide {{ flex: 1 1 100%; }}
        .card h3 {{ color: #e2e8f0; font-size: 16px; margin-top: 0; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 10px; }}
        .card p {{ font-size: 13px; color: #a0aec0; }}
        .card img {{ max-width: 100%; border-radius: 6px; margin-top: 15px; border: 1px solid rgba(0,170,255,0.3); box-shadow: 0 4px 15px rgba(0,0,0,0.5); }}
        table {{ width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 14px; }}
        th, td {{ border: 1px solid rgba(0, 170, 255, 0.2); padding: 12px; text-align: left; }}
        th {{ background-color: rgba(0, 170, 255, 0.1); color: #00aaff; font-weight: bold; }}
        td {{ background-color: rgba(10, 16, 28, 0.5); }}
        .fail {{ color: #ff3333; font-weight: bold; }}
        .pass {{ color: #00ff88; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>DEEPFAKE FORENSIC ANALYSIS REPORT</h1>
    </div>
    <div class="meta">
        SCAN ID: {scan_id} &nbsp;|&nbsp; TIMESTAMP: {timestamp}
    </div>
    
    <div class="verdict-box">
        <h2>FINAL ASSESSMENT: {v_title}</h2>
        <p style="font-size:16px;"><strong>Confidence:</strong> {verdict['confidence']}% &nbsp;|&nbsp; <strong>Risk Level:</strong> {verdict['risk_level']} &nbsp;|&nbsp; <strong>System Score:</strong> {verdict['fake_score']}/100</p>
        <p style="color: #c9d1d9; line-height: 1.6; margin-top: 15px;"><strong>Executive Summary:</strong> {summary}</p>
    </div>

    <div class="section-title">01 // Spatial Analysis Evidence</div>
    <div class="grid">
        <div class="card">
            <h3>Source + ROI Bounding Box</h3>
            <img src="data:image/png;base64,{images['bbox']}" />
        </div>
        <div class="card">
            <h3>Geometric Mesh (468-PT)</h3>
            <img src="data:image/png;base64,{images['mesh']}" />
        </div>
        <div class="card">
            <h3>Error Level Heatmap</h3>
            <img src="data:image/png;base64,{images['ela']}" />
        </div>
    </div>

    <div class="section-title">02 // Heuristic Engine Telemetry</div>
    <div class="grid">
        <div class="card">
            <h3>FFT Spectrum Signature</h3>
            <p><strong>Score: {engines['fft']['score']}/100</strong><br>{engines['fft']['status']}</p>
            <img src="data:image/png;base64,{images['fft']}" />
        </div>
        <div class="card">
            <h3>LBP Texture Entropy</h3>
            <p><strong>Score: {engines['texture']['score']}/100</strong><br>{engines['texture']['status']}</p>
            <img src="data:image/png;base64,{images['lbp']}" />
        </div>
        <div class="card">
            <h3>Color Boundary Delta</h3>
            <p><strong>Score: {engines['color']['score']}/100</strong><br>{engines['color']['status']}</p>
            <img src="data:image/png;base64,{images['color']}" />
        </div>
    </div>

    <div class="section-title">03 // Facial Geometry Constraints</div>
    <div class="card card-wide">
        <table>
            <tr><th>Metric</th><th>Measured</th><th>Normal Range</th><th>Deviation</th><th>Status</th></tr>
            {table_rows}
        </table>
    </div>

    <div class="section-title">04 // Reference Analysis</div>
    <div class="card card-wide" style="text-align:left;">
        <h3>Identity Verification Result</h3>
        <p><strong>Similarity Score:</strong> {sim}%</p>
        <p><strong>Result:</strong> {match_str}</p>
        <p><strong>Engine Status:</strong> {cmp_lbl}</p>
    </div>

    <p style="text-align:center; margin-top: 60px; font-size: 12px; color: #4a5568;">Generated securely by DeepFake Forensics Terminal.<br>For official investigative use.</p>
</body>
</html>"""
            return html

        images_dict = {
            "bbox": to_b64(bbox_img),
            "mesh": to_b64(mesh_overlay_arr if mesh_overlay_arr is not None else img_arr),
            "ela": to_b64(ela_viz) if ela_viz else "",
            "fft": to_b64(fft_viz) if fft_viz else "",
            "lbp": to_b64(lbp_viz) if lbp_viz else "",
            "color": to_b64(color_viz) if color_viz else ""
        }

        report_html = generate_rich_html_report(scan_id, timestamp, {
            "ela": ela_result, "fft": fft_result, "geometry": geo_result,
            "texture": tex_result, "color": col_result
        }, verdict, images_dict, geo_result.get("table"), face_cmp=face_cmp)

        st.download_button("DOWNLOAD RICH FORENSIC REPORT (.HTML)", data=report_html.encode("utf-8"), file_name=f"sys_report_{scan_id}.html", mime="text/html")
        
        if st.button("↻ INITIATE NEW SCAN"):
            for key in ["scan_active", "scan_done", "results"]:
                st.session_state.pop(key, None)
            st.rerun()
            
        st.markdown('</div>', unsafe_allow_html=True)
